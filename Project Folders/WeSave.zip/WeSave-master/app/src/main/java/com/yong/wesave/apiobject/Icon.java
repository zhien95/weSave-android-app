package com.yong.wesave.apiobject;

/**
 * Created by Yong0156 on 28/2/2017.
 */


public class Icon {
    public String prefix;
    public String suffix;
}
