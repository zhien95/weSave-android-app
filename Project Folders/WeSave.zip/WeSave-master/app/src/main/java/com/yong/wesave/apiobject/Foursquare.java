package com.yong.wesave.apiobject;

/**
 * Created by Yong0156 on 28/2/2017.
 */

import java.io.Serializable;

public class Foursquare implements Serializable {
    private static final long serialVersionUID = 888L;
    public Response response;
}
