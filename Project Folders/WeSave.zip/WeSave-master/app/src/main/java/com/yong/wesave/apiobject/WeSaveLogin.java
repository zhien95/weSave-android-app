package com.yong.wesave.apiobject;

/**
 * Created by Yong on 11/12/2016.
 */
public class WeSaveLogin {
    public String Username;
    public String Password;
    public String Email;
}
