package com.yong.wesave.apiobject;

/**
 * Created by Yong on 11/12/2016.
 */
public class Status {
    public int Code;
    public String Message;
}
