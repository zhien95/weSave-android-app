package com.yong.wesave.apiobject;

/**
 * Author: Koo Yan Chong
 * Last updated date: 26/3/2018
 */

public class Category {
    public int id;
    public String category_name;
    public int level;
    //public String image;

    public int getId() {
        return id;
    }

    public String getCategoryName() {
        return category_name;
    }

    public int getLevel() {
        return level;
    }
    //public String getImage(){ return image; }
}

