package com.yong.wesave.common;

/**
 * Created by Yong on 4/1/2017.
 */

/**
 * Author: Koo Yan Chong
 * Last updated date: 26/3/2018
 */

public class Constants {
    public static final String NTU_WIFI = "10.27.184.212";
    public static final String ROOM_WIFI = "192.168.1.110";

   public static final String API_BASE_URL = "http://" + ROOM_WIFI + ":3000";
 //   public static final String API_BASE_URL = "http://" + NTU_WIFI + ":3000";
   //  public static final String API_BASE_URL = "http://18.136.194.26:3000";
    public static final String API_BASE_URL_API = API_BASE_URL + "/api/";
    public static final String API_BASE_URL_ITEM_IMAGES = API_BASE_URL + "/uploads/item_images/";
    public static final String API_BASE_URL_STORE_IMAGES = API_BASE_URL + "/uploads/store_images/";
    public static final String TOKEN = "token";
    //public static final String EMAIL = "sg.wesave@gmail.com]"; //pw: Singaporewesave
    public static final String EMAIL = "appwesave@gmail.com"; //pw: WeSave1234



    public static final String API_ADD_STORE = "addstore";
    public static final String API_GET_ALL_STORES = "getallstores";
    public static final String API_ADD_PRICE = "addprice";
    public static final String API_GET_ITEM = "getitem";

}