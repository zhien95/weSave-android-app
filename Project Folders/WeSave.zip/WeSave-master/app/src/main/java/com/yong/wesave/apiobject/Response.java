package com.yong.wesave.apiobject;

/**
 * Created by Yong on 11/12/2016.
 */

import java.util.List;

public class Response {

    public List<Venue> venues;
}
