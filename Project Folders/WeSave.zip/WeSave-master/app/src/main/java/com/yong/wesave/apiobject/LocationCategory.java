package com.yong.wesave.apiobject;

/**
 * Created by Yong0156 on 28/2/2017.
 */
public class LocationCategory {
    public String id;
    public String name;
    public Icon icon;
    public boolean primary;
}
