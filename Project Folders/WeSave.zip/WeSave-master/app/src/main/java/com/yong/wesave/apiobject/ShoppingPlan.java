package com.yong.wesave.apiobject;

/**
 * Created by Yong0156 on 21/2/2017.
 */

public class ShoppingPlan {
    public int id;
    public String plan_name;
    public String plan;
    public String total;

    public String getName() {
        return plan_name;
    }
}
