package com.yong.wesave.common;

/**
 * Created by Yong on 11/12/2016.
 */
public class ApiConstant {
    /* For general requests */
    public static final int OK = 0;
}
